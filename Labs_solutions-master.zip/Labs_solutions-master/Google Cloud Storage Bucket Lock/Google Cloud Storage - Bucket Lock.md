
## **Google Cloud Storage - Bucket Lock**

## **Just Copy & Paste the commands**

```
curl -LO raw.githubusercontent.com/quiccklabs/Labs_solutions/master/Google%20Cloud%20Storage%20Bucket%20Lock/quicklabgsp297.sh

sudo chmod +x quicklabgsp297.sh

./quicklabgsp297.sh
```


## Congratulation