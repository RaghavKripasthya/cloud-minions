inventory = [
    {
        "productid": "P001",
        "onhandqty": "10"
    },
    {
        "productid": "P002",
        "onhandqty": "20"
    },
    {
        "productid": "P003",
        "onhandqty": "30"
    }
]