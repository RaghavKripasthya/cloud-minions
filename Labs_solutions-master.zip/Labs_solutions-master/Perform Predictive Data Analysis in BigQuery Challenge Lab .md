



## Perform Predictive Data Analysis in BigQuery: Challenge Lab

## OPEN YOUR CLOUD SHELL

##  ONLY USE ONLINE NOTEPAD WHICH I WAS USING 🙏🏻


### EXPORT Values 

```bash
export EVENT_NAME=

export TABLE_NAME=

export VALUE_X_1=

export VALUE_Y_1=

export VALUE_X_2=

export VALUE_Y_2=

export FUNCTION_1=

export FUNCTION_2=

export MODEL_NAME=
```


###
###

## NOW JUST COPY AND PASTE ON YOUR CLOUD SHELL

```bash
curl -LO raw.githubusercontent.com/quiccklabs/Labs_solutions/master/Predict%20Soccer%20Match%20Outcomes%20with%20BigQuery%20ML%20Challenge%20Lab/quicklabgsp374.sh

sudo chmod +x quicklabgsp374.sh

./quicklabgsp374.sh
```


#### perform task 4.1 & 4.2 manually as I explain in the video.




## Congratulation !!!
