

## Activity: Get help in the command line


##


```bash
whatis cat
```
##
```bash
man cat
```
##
#### Press Q to exit this manual page.

##
```bash
apropos -a first part file
```
##

```bash
man useradd
```

#### Press Q to exit this manual page.

```bash
whatis rm

whatis rmdir

apropos -a "create new group"
```


## Congratulation !!!
