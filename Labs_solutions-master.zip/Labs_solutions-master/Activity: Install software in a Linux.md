##  Activity: Install software in a Linux distribution




***Start the lab and run the below commands***


```bash
apt

sudo apt install suricata

suricata --version
```
###

***Check the score for task 1***

```bash
sudo apt remove suricata -y

suricata --version
```

***Check the score for task 2***

```bash
sudo apt install tcpdump
```
####
***Check the score for task 3***


```bash
apt list --installed

apt list --installed | grep tcpdump
```

####
***Check the score for task 4***

```bash
sudo apt install suricata -y
```
####
***Check the score for task 5***

###
## Congratulations !!!

