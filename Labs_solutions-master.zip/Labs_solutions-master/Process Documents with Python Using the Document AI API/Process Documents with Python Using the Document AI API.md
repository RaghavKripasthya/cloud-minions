
# Process Documents with Python Using the Document AI API


#### **Run command in cloud shell**

```bash
curl -LO raw.githubusercontent.com/quiccklabs/Labs_solutions/master/Process%20Documents%20with%20Python%20Using%20the%20Document%20AI%20API/quickklabgsp925.sh

sudo chmod +x quickklabgsp925.sh

./quickklabgsp925.sh

```


### **Run command in juypter NoteBook**

```bash
curl -LO raw.githubusercontent.com/quiccklabs/Labs_solutions/master/Process%20Documents%20with%20Python%20Using%20the%20Document%20AI%20API/quicklab.sh

sudo chmod +x quicklab.sh

./quicklab.sh

```

## Now wait for 5 minutes maximum 

## Congratulation!!!
