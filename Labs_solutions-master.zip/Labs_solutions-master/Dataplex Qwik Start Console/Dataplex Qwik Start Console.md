## Dataplex: Qwik Start - Console

##

```
export REGION=
```


```
curl -LO raw.githubusercontent.com/quiccklabs/Labs_solutions/master/Dataplex%20Qwik%20Start%20Console/quicklabtask1.sh

sudo chmod +x quicklabtask1.sh

./quicklabtask1.sh
```
### ***Now Check the score for First 3 Task  & then go ahead with next Commands.***

##



```
curl -LO raw.githubusercontent.com/quiccklabs/Labs_solutions/master/Dataplex%20Qwik%20Start%20Console/quicklabtask2.sh

sudo chmod +x quicklabtask2.sh

./quicklabtask2.sh
```

### Congratulation!!!