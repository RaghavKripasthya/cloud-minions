## Deploy a Hugo Website with Cloud Build and Firebase Pipeline

##

[![Screenshot-2024-06-30-at-1-46-19-AM.png](https://i.postimg.cc/1z2471v2/Screenshot-2024-06-30-at-1-46-19-AM.png)](https://postimg.cc/hJ8Sh6W1)



```
curl -LO https://raw.githubusercontent.com/quiccklabs/Labs_solutions/master/Deploy%20a%20Hugo%20Website%20with%20Cloud%20Build%20and%20Firebase%20Pipeline/quicklabtask1.sh

source quicklabtask1.sh
```
***Now Check the score for Task 2 & then go ahead with next Commands.***

##
```
curl -LO https://raw.githubusercontent.com/quiccklabs/Labs_solutions/master/Deploy%20a%20Hugo%20Website%20with%20Cloud%20Build%20and%20Firebase%20Pipeline/quicklabtask2.sh

source quicklabtask2.sh
```

[![Screenshot-2024-06-29-at-2-47-57-AM.png](https://i.postimg.cc/0NR7rmsb/Screenshot-2024-06-29-at-2-47-57-AM.png)](https://postimg.cc/k2s2p2Dm)

#



### Congratulation!!!
