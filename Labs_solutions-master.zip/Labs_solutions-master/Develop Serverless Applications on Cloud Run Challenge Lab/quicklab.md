
# Develop Serverless Applications on Cloud Run: Challenge Lab

## Environment Variables

Set the following environment variables:

```bash
export REGION=

export TASK_1_SERVICES_NAME=

export TASK_2_SERVICES_NAME=

export TASK_3_SERVICES_NAME=

export TASK_4_SERVICES_NAME=

export TASK_5_SERVICES_NAME=

export TASK_6_SERVICES_NAME=

export TASK_7_SERVICES_NAME=
```

## Script Execution



```bash
curl -LO raw.githubusercontent.com/quiccklabs/Labs_solutions/master/Develop%20Serverless%20Applications%20on%20Cloud%20Run%20Challenge%20Lab/quicklabgsp328.sh

sudo chmod +x quicklabgsp328.sh

./quicklabgsp328.sh
```

## Congratulation!!!
