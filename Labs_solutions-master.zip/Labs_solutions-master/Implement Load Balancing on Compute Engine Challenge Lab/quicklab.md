


## ***```Implement Load Balancing on Compute Engine: Challenge Lab```***

## Export all the values carefully
#
### **Lab is updated so no need to export the value of port**

```bash
export INSTANCE_NAME=

export ZONE=

export FIREWALL_NAME=
```
###
###

### ***NOW JUST COPY THE CODE AND PASTE ON YOUR CLOUD SHELL***
###
###

```bash 
curl -LO raw.githubusercontent.com/quiccklabs/Labs_solutions/master/Implement%20Load%20Balancing%20on%20Compute%20Engine%20Challenge%20Lab/quicklabgsp313.sh
sudo chmod +x quicklabgsp313.sh
./quicklabgsp313.sh
```

### Lab might task 10 - 15 mintues to updated the score so don't worry!

[![Screenshot-2024-03-25-at-7-47-33-PM.png](https://i.postimg.cc/Vk2hdZfK/Screenshot-2024-03-25-at-7-47-33-PM.png)](https://postimg.cc/zyS7QjRh)


### Congratulations !!!
