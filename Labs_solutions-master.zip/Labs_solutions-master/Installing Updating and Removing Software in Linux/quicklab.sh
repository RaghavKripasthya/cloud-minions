

dpkg -s firefox-esr

dpkg -s gimp

dpkg -s vlc

echo 'Y' | sudo apt-get install -f 

dpkg -s vlc

sudo apt-get update

echo 'Y' | sudo apt-get install firefox-esr

dpkg -s firefox-esr

echo 'Y' | sudo apt-get remove gimp

dpkg -s gimp